create FUNCTION MaximalDistance
    RETURN NUMBER IS 
        v_min_prod_year NUMBER;
        v_max_prod_year NUMBER;
BEGIN
    SELECT MIN(PROD_YEAR) INTO v_min_prod_year FROM MediaItems;
    SELECT MAX(PROD_YEAR) INTO v_max_prod_year FROM MediaItems;
    RETURN POWER((v_max_prod_year - v_min_prod_year), 2);
END MaximalDistance;
/

