create FUNCTION SimCalculation(mid1 IN NUMBER, mid2 IN NUMBER, maximal_distance IN NUMBER)
    RETURN FLOAT IS 
        v_two_items_distance NUMBER;
        v_mid1_prod_year NUMBER;
        v_mid2_prod_year NUMBER;
BEGIN
    SELECT PROD_YEAR INTO v_mid1_prod_year FROM MediaItems WHERE MID=mid1;
    SELECT PROD_YEAR INTO v_mid2_prod_year FROM MediaItems WHERE MID=mid2;
    v_two_items_distance := POWER((v_mid1_prod_year - v_mid2_prod_year), 2);
    RETURN (1 - (v_two_items_distance/maximal_distance));
END SimCalculation;
/

