create trigger AUTOINCREMENT
  before insert
  on MEDIAITEMS
  for each row
  DECLARE
        v_mid_index NUMBER;
    BEGIN
        SELECT MAX(MID) INTO v_mid_index FROM MediaItems;
        IF v_mid_index IS NULL THEN
            :new.MID := 0;
        ELSE
            :new.MID := v_mid_index + 1;
        END IF;
        :new.TITLE_LENGTH := LENGTH(:new.TITLE);
END;
/

